//
//  ViewController.swift
//  ProgrammingTest
//
//  Created by GK on 2017/11/24.
//  Copyright © 2017年 GK. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputAddressField: UITextField!
    @IBOutlet weak var transferResultLabel: UILabel!
    
    let ipv4Model = IPV4AddressModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.inputAddressField.text = "172.168.5.1"
    }

    @IBAction func transferButtonClicked(_ sender: UIButton) {
        
        let textFieldString = self.inputAddressField.text
        
        guard let inputString = textFieldString else {

            return
        }
        if !ipv4Model.validateInputIPV4Address(address: inputString) {
            showAlert(alertText: "输入了错误的IPV4地址，注意两个数字之间不能包含任何字符")
            return
        }
        
        let parseNumbers = ipv4Model.matchNumberInString(str: inputString)
    
        self.transferResultLabel.text = ipv4Model.transferIPV4ToInt32(addressIntArray: parseNumbers)
    }
    
   
    func showAlert(alertText: String) {
        let alertView = UIAlertController(title: "", message: alertText, preferredStyle: UIAlertControllerStyle.alert)
        let cancelAction = UIAlertAction(title: "知道了", style: UIAlertActionStyle.cancel, handler: nil)
        alertView.addAction(cancelAction)
        show(alertView, sender: nil)
    }
}

extension ViewController: UITextFieldDelegate {

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        self.transferResultLabel.text = ""

        return true
    }
}
