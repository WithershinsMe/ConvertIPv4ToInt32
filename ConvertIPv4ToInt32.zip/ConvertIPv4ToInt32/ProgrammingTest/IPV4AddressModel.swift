//
//  IPV4AddressModel.swift
//  ProgrammingTest
//
//  Created by GK on 2017/11/25.
//  Copyright © 2017年 GK. All rights reserved.
//

import Foundation

class IPV4AddressModel {
    
    func validateInputIPV4Address(address: String) -> Bool {
        
        let tmpAddress = address.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        let regexPattern = "^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\s*\\.\\s*){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"
        let regex = try! NSRegularExpression(pattern: regexPattern,
                                             options: .caseInsensitive)
        
        let matchRange = regex.rangeOfFirstMatch(in: tmpAddress, options: NSRegularExpression.MatchingOptions.reportProgress, range: NSMakeRange(0, tmpAddress.utf16.count))
        return matchRange.location != NSNotFound
    }
    func matchNumberInString(str: String) -> [Int] {
        let numberRegexString = "\\d{1,3}"
        let numberRegex = try! NSRegularExpression(pattern: numberRegexString,
                                                   options: .caseInsensitive)
        let matches = numberRegex.matches(in: str, options:[], range: NSMakeRange(0, str.utf16.count))
        
        var results = [Int]()
        for match in matches {
            let numberString =  String(str[Range(match.range, in: str)!])
            if let number = NumberFormatter().number(from: numberString) {
                results.append(number.intValue)
            }
        }
        return results
    }
    func transferIPV4ToInt32(addressIntArray:[Int]) -> String {
        var resultInt32 = 0
        let numbersCount = addressIntArray.count;
        for number in addressIntArray {
            let i = addressIntArray.index(of: number)
            resultInt32 = number << ((numbersCount - 1 - i!) * 8) + resultInt32
        }
        return "\(resultInt32)"
    }
}
