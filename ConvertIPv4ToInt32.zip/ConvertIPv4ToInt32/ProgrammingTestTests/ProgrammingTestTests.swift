//
//  ProgrammingTestTests.swift
//  ProgrammingTestTests
//
//  Created by GK on 2017/11/24.
//  Copyright © 2017年 GK. All rights reserved.
//

import XCTest
@testable import ProgrammingTest

class ProgrammingTestTests: XCTestCase {
    
    let ipv4Model = IPV4AddressModel()
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testValidateIPV4Address() {
        let zeroAddress = "0.0.0.0"
        let errorAddress = "172.168.5.1.45"
        let outOfRangeAddress = "172.168.456.23"
        let numberSpaceAddress = "172.1 68.5.1"
        let dotSpaceAddress = "172 . 168.5. 1"
        let correctAddress = "172.168.5.1"
    
        assert(true == ipv4Model.validateInputIPV4Address(address: zeroAddress),"0 IPv4 address should validate success")
        assert(false == ipv4Model.validateInputIPV4Address(address: errorAddress),"error ipv4 address should validate failure")
        assert(false == ipv4Model.validateInputIPV4Address(address: outOfRangeAddress),"address number should in range [0-255],so should validate failure")
        assert(false == ipv4Model.validateInputIPV4Address(address: numberSpaceAddress),"error address : a string with spaces between two digits should validate failure")
        assert(true == ipv4Model.validateInputIPV4Address(address: dotSpaceAddress),"correct address error: a string with sapces between a digit and dot shoudl validate success")
        assert(true == ipv4Model.validateInputIPV4Address(address: correctAddress),"correct address error : correct address validate should success")
    }
    func testMatchNumberInString() {
        let address = "172.168.5.1"
        let numbers = ipv4Model.matchNumberInString(str: address)
        
        assert(172 == numbers[0], "first element is not 172")
        assert(168 == numbers[1], "second element is not 168")
        assert(5 == numbers[2], "third element is not 5")
        assert(1 == numbers[3], "fourth element is not 1")
    }
    
    func testTransferIPV4ToInt32() {
        let address = "172.168.5.1"
        
        let result = ipv4Model.transferIPV4ToInt32(addressIntArray: ipv4Model.matchNumberInString(str: address))
        assert("2896692481" == result, "Ipv4 address convert to 32 bit integer error")
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
